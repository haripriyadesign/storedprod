package com.quartz.simple;

import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

public class QuartzExample {

	public static void main(String[] args) {
		SchedulerFactory schedFact = new StdSchedulerFactory();
        try {
            Scheduler sched = schedFact.getScheduler();
            Trigger triggerA = TriggerBuilder.newTrigger().withIdentity("triggerA", "group2").startNow()
            		.withPriority(15)
            		.withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(40).repeatForever())
            		.build();
            JobDetail jobA = JobBuilder.newJob(JobA.class).withIdentity("jobA", "group2").build();
            sched.scheduleJob(jobA, triggerA);
            sched.start();
        }catch (Exception e) {
			// TODO: handle exception
		}
            
	}

}
